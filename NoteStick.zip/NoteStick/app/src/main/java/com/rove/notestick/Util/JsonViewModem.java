package com.rove.notestick.Util;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.rove.notestick.CustomViews.StringImageScrollView;

import java.util.List;

public class JsonViewModem {
    String mJsonString;
    StringImageScrollView scrollView;
    List<String> imageUri;
    public static final int EDITEXT_TYPE = 1;
    public static final int IMAGEVIEW_TYPE = 2;

    public static final int SIZE_WRAPCONTENT = -1;
    public static final int SIZE_MATCHPARENT = -2;

    public JsonViewModem(StringImageScrollView scrollView, List<String> imageUri) {
        this.scrollView = scrollView;
        this.imageUri = imageUri;
    }

    public String getJsonfromView(){
        int viewcount = scrollView.getChildCount();
        JsonArray jsonArray = new JsonArray();
        ContentView contentView;
        for(int i=0; i<viewcount;i++){
            View view = scrollView.getChildAt(i);
            if(view instanceof EditText){
                EditText editText = (EditText)view;
                contentView = new ContentView(EDITEXT_TYPE,editText.getText().toString(),
                        new ViewSize(SIZE_MATCHPARENT,SIZE_WRAPCONTENT));
            }
            else if(view instanceof ImageView){
                ImageView imageView = (ImageView) view;
                contentView = new ContentView(IMAGEVIEW_TYPE,imageUri.get(i),
                        new ViewSize(imageView.getWidth(),imageView.getHeight()));
            }
            else {
                contentView = null;
            }
           String jsonObj = new Gson().toJson(contentView);
           jsonArray.add(jsonObj);
        }
        return jsonArray.toString();
    }

    private class ContentView{
        private int viewType;
        private String content;
        private ViewSize viewSize;

        public ContentView(int viewType, String content,ViewSize viewSize) {
            this.viewType = viewType;
            this.content = content;
            this.viewSize = viewSize;
        }
    }

    private class ViewSize{
        private int Width;
        private int Height;

        public ViewSize(int width, int height) {
            Width = width;
            Height = height;
        }
    }


}
