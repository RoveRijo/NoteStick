package com.rove.notestick.CustomViews;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

public class ImageViewWithSrc extends android.support.v7.widget.AppCompatImageView {
    public ImageViewWithSrc(Context context) {
        super(context);
    }

    public ImageViewWithSrc(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ImageViewWithSrc(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ImageViewWithSrc(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }
}
