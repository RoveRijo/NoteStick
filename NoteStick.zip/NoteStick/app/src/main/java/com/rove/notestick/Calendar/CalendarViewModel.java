package com.rove.notestick.Calendar;

import androidx.lifecycle.ViewModel;

public class CalendarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
