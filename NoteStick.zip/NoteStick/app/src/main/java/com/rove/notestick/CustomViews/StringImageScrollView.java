package com.rove.notestick.CustomViews;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ScrollView;


import androidx.annotation.RequiresApi;

public class StringImageScrollView extends ScrollView {

    public StringImageScrollView(Context context) {
        super(context);
    }

    public StringImageScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public StringImageScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public StringImageScrollView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }



}

