package com.rove.notestick.Util;

import java.util.ArrayList;
import java.util.List;

public class NoteContentParser {
    private String content;

    public NoteContentParser(String content) {
        this.content = content;
    }
    public List<String> getContents(){
        List<String> contents = new ArrayList<>();



        return  contents;
    }
}
