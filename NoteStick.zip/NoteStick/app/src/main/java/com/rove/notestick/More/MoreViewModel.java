package com.rove.notestick.More;

import androidx.lifecycle.ViewModel;

public class MoreViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
