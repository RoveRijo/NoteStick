package com.rove.notestick.Util;

import android.content.Context;
import android.text.Editable;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.rove.notestick.CustomViews.StringImageScrollView;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class JsonViewModemTest {
    //@Mock
    //private Context context;
    @Mock
    private EditText editText;
    @Mock
    ImageView imageView1,imageView2;
    @Mock
    private StringImageScrollView scrollView;
    @Mock
    Editable editable;

    List<String> uri;
    String textviewstr = "first text view";
    String imageviewstr1 = "image1";
    String imageviewstr2 = "image2";

    @Before
    public void setUp(){

        uri = new ArrayList<>();
        uri.add(imageviewstr1);
        uri.add(imageviewstr2);

        when(scrollView.getChildCount()).thenReturn(3);
        when(scrollView.getChildAt(0)).thenReturn(editText);
        when(scrollView.getChildAt(1)).thenReturn(imageView1);
        when(scrollView.getChildAt(2)).thenReturn(imageView2);

        when(editable.toString()).thenReturn(textviewstr);

        when(editText.getText()).thenReturn(editable);
        when(imageView1.getWidth()).thenReturn(100);
        when(imageView1.getHeight()).thenReturn(100);
        when(imageView2.getWidth()).thenReturn(100);
        when(imageView2.getHeight()).thenReturn(100);


    }

    @Test
    public void isgetJsonFromViewWorks(){
        JsonViewModem jsonViewModem = new JsonViewModem(scrollView,uri);
        String JsonArray = jsonViewModem.getJsonfromView();
        System.out.println(JsonArray);
        assert(true);


    }

}